# inference.py
# takes the training from the fine_tune.py and uses it to predict what the user wants based on their input

from transformers import T5ForConditionalGeneration, T5Tokenizer
from . import config

def generate_upgraded_text(input_text, genre):
    """
    Generate an upgraded sentence based on the specified genre.
    
    Args:
    - input_text: The sentence to be upgraded.
    - genre: The genre (e.g., "fantasy", "sci-fi", "detective", etc.)
    
    Returns:
    - upgraded_text: The upgraded sentence in the style of the specified genre.
    """
    # Load the fine-tuned model and tokenizer from the config directory
    tokenizer = T5Tokenizer.from_pretrained(config.OUTPUT_DIR)
    model = T5ForConditionalGeneration.from_pretrained(config.OUTPUT_DIR)

    # Combine the input text with the genre context
    input_with_genre = f"[genre: {genre}] {input_text}"

    # Tokenize the input with the genre
    inputs = tokenizer(input_with_genre, return_tensors="pt").input_ids

    # Generate the upgraded sentence
    outputs = model.generate(inputs, max_length=100)
    upgraded_text = tokenizer.decode(outputs[0], skip_special_tokens=True)

    return upgraded_text

if __name__ == "__main__":
    # Ask user for input
    paragraph = input("Enter a sentence to improve: ")
    genre = input("Specify the genre (e.g., fantasy, sci-fi, detective): ")
    
    # Generate upgraded text based on genre
    improved_text = generate_upgraded_text(paragraph, genre)
    
    # Print the upgraded text
    print("Suggested Edit:", improved_text)