from django.shortcuts import render
from .presenters import ChatbotPresenter

def chatbot_view(request):
    response = ""
    user_input = ""
    genre = "general"
    
    if request.method == "POST":
        user_input = request.POST.get("user_input", "")
        genre = request.POST.get("genre", "general")
        presenter = ChatbotPresenter()
        response = presenter.get_response(user_input, genre)
    
    return render(request, 'chatbot/index.html', {
        'response': response,
        'user_input': user_input,
        'selected_genre': genre
    })
