# data_loader.py
# Loads the data input-output pairs from dataset.json
# 'Tokenizing' is converting the input-output pairs into tokens that the model can understand

from datasets import load_dataset
from transformers import T5Tokenizer

def load_and_preprocess_data(tokenizer, dataset_path, max_length=512):
    """
    Load and preprocess both training and evaluation datasets.

    Args:
    - tokenizer: The tokenizer to be used for tokenizing input and output.
    - dataset_path: Path to the JSON dataset file.
    - max_length: Maximum token length.

    Returns:
    - tokenized_datasets: A dictionary with "train" and "test" datasets.
    """
    # Load the dataset
    print(f"Loading dataset from {dataset_path}")
    dataset = load_dataset('json', data_files={'train': dataset_path})

    # Split dataset into train and eval sets (80% train, 20% eval)
    dataset = dataset['train'].train_test_split(test_size=0.2)

    # Preprocess function to tokenize inputs and outputs
    def preprocess_function(examples):
        inputs = examples['input']  # Original paragraph
        targets = examples['output']  # Edited paragraph
        model_inputs = tokenizer(inputs, max_length=max_length, truncation=True, padding='max_length')
        
        # Tokenize the output (target text)
        labels = tokenizer(targets, max_length=max_length, truncation=True, padding='max_length').input_ids
        model_inputs['labels'] = labels
        return model_inputs

    # Apply the preprocess function to both train and eval datasets
    tokenized_datasets = dataset.map(preprocess_function, batched=True)

    return tokenized_datasets

if __name__ == "__main__":
    tokenizer = T5Tokenizer.from_pretrained('t5-small')
    dataset_path = "../data/my_dataset.json"
    processed_data = load_and_preprocess_data(tokenizer, dataset_path)
    print("Data loaded and preprocessed successfully.")
    