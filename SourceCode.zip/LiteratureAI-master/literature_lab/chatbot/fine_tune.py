# fine_tune.py
# script to train the model based on the tokens from the data_loader.py file

from transformers import T5ForConditionalGeneration, T5Tokenizer, Trainer, TrainingArguments
from data_loader import load_and_preprocess_data
import config  # Import configuration settings

def fine_tune_model():
    """
    Fine-tune the model on the dataset with evaluation.
    """
    tokenizer = T5Tokenizer.from_pretrained(config.MODEL_NAME)
    model = T5ForConditionalGeneration.from_pretrained(config.MODEL_NAME)

    # Load and preprocess the dataset
    datasets = load_and_preprocess_data(tokenizer, config.DATA_PATH)

    # Get train and eval datasets
    train_dataset = datasets['train']
    eval_dataset = datasets['test']  # The validation split

    # Set up training arguments
    training_args = TrainingArguments(
        output_dir=config.OUTPUT_DIR,
        evaluation_strategy="epoch",  # Enable evaluation per epoch
        learning_rate=config.LEARNING_RATE,
        per_device_train_batch_size=config.BATCH_SIZE,
        num_train_epochs=config.NUM_EPOCHS,
        weight_decay=config.WEIGHT_DECAY,
        save_total_limit=2
    )

    # Initialize Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset  # Provide the eval dataset
    )

    # Fine-tune the model
    trainer.train()

    # Save the fine-tuned model
    model.save_pretrained(config.OUTPUT_DIR)
    tokenizer.save_pretrained(config.OUTPUT_DIR)

if __name__ == "__main__":
    fine_tune_model()
