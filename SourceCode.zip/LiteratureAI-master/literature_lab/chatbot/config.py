# config.py

import os

# Base Directory Path for Github Accessibility
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Model configuration
MODEL_NAME = "t5-small"

DATA_PATH = os.path.join(BASE_DIR, "chatbot", "data", "my_dataset.json")
OUTPUT_DIR = os.path.join(BASE_DIR, "chatbot", "models", "fine_tuned_model")

# Training configuration
BATCH_SIZE = 16
NUM_EPOCHS = 5
LEARNING_RATE = 5e-5
WEIGHT_DECAY = 0.001