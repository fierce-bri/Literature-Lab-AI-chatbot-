from .models import UserQuery
from .views_gui import ViewGUI
from chatbot.inference import generate_upgraded_text  # Import AI text generation function
import tkinter as tk
from tkinter import messagebox

class ChatbotPresenter:
    def __init__(self):
        pass

    def get_response(self, input_text, genre="general"):
        # Generate an upgraded response based on the user input and genre
        ai_response = generate_upgraded_text(input_text, genre)
        return ai_response

