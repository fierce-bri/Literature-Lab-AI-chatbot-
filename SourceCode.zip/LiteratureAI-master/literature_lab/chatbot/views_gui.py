import tkinter as tk
from tkinter import messagebox

class ViewGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Literature Lab Chatbot")
        self.root.geometry("500x450")

        # Input label
        self.input_label = tk.Label(root, text="Enter your text:")
        self.input_label.pack(pady=10)

        # Input text area
        self.input_text = tk.Text(root, height=10, width=50)
        self.input_text.pack()

        # Genre label
        self.genre_label = tk.Label(root, text="Choose a genre:")
        self.genre_label.pack(pady=10)

        # Genre selection dropdown (OptionMenu)
        self.genre_selector = tk.StringVar(root)
        self.genre_selector.set("general")  # Default value
        self.genre_menu = tk.OptionMenu(root, self.genre_selector, "general", "fantasy", "sci-fi", "detective")
        self.genre_menu.pack()

        # Submit button
        self.submit_button = tk.Button(root, text="Submit", width=10)
        self.submit_button.pack(pady=10)

        # Response label
        self.response_label = tk.Label(root, text="Response:")
        self.response_label.pack(pady=10)

        # Response text area (disabled by default)
        self.response_text = tk.Text(root, height=5, width=50, state='disabled')
        self.response_text.pack()